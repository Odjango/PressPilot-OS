<?php
/**
 * Clean functions.php for content provisioning.
 * Focuses on essential logic: page creation and site settings.
 */

// Universal function to create required pages on theme activation.
// Universal function to create required pages
function presspilot_create_required_pages()
{
    $pages_created = false;
    // Universal set of pages to create
    $pages_to_create = array(
        'Home' => 'home',
        'Menu' => 'menu',
        'About' => 'about',
        'Services' => 'services',
        'Blog' => 'blog',
        'Contact' => 'contact'
    );

    foreach ($pages_to_create as $page_title => $page_slug) {
        // Check if the page already exists (by slug)
        if (!get_page_by_path($page_slug)) {
            $page_data = array(
                'post_type' => 'page',
                'post_title' => $page_title,
                'post_name' => $page_slug,
                'post_content' => '<!-- wp:paragraph --><p>This is the ' . $page_title . ' page. Edit this content via Dashboard > Pages.</p><!-- /wp:paragraph -->',
                'post_status' => 'publish',
                'post_author' => 1
            );
            wp_insert_post($page_data);
            $pages_created = true;
        }
    }

    // Set 'Home' as the static front page and 'Blog' as the posts page.
    $home_page = get_page_by_path('home');
    $blog_page = get_page_by_path('blog');

    if ($home_page) {
        update_option('page_on_front', $home_page->ID);
        update_option('show_on_front', 'page');
    }
    if ($blog_page) {
        update_option('page_for_posts', $blog_page->ID);
    }

    return $pages_created;
}

// Hook into theme activation
add_action('after_switch_theme', 'presspilot_create_required_pages');

// Robust fallback: Check on admin_init if content is missing
function presspilot_ensure_content_on_admin()
{
    // Always check if the 'home' page exists. If not, trigger creation.
    // This ensures that if the user deletes pages or they weren't created, we try again.
    if (!get_page_by_path('home')) {
        presspilot_create_required_pages();
    }
}
add_action('admin_init', 'presspilot_ensure_content_on_admin');
