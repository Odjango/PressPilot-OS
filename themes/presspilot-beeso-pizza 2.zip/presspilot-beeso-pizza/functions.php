<?php
/**
 * Theme functions and definitions
 */

if ( ! function_exists( 'presspilot_beeso_pizza_support' ) ) :
	function presspilot_beeso_pizza_support() {
		add_theme_support( 'wp-block-styles' );
		add_theme_support( 'editor-styles' );
		add_theme_support( 'block-templates' );
	}
endif;
add_action( 'after_setup_theme', 'presspilot_beeso_pizza_support' );

/**
 * Register block patterns
 */
function presspilot_beeso_pizza_register_patterns() {
    register_block_pattern_category(
        'featured',
        array( 'label' => __( 'Featured', 'presspilot-beeso-pizza' ) )
    );
}
add_action( 'init', 'presspilot_beeso_pizza_register_patterns' );
