<?php
/**
 * Clean functions.php for content provisioning.
 * Focuses on essential logic: page creation and site settings.
 */

// Universal function to create required pages on theme activation.
function presspilot_create_required_pages()
{
    // Universal set of pages to create
    $pages_to_create = array(
        'Home' => 'home',
        'Menu' => 'menu',
        'About' => 'about',
        'Services' => 'services',
        'Blog' => 'blog',
        'Contact' => 'contact'
    );

    foreach ($pages_to_create as $page_title => $page_slug) {
        // Check if the page already exists (by slug)
        if (!get_page_by_path($page_slug)) {
            $page_data = array(
                'post_type' => 'page',
                'post_title' => $page_title,
                'post_name' => $page_slug,
                'post_content' => '<p>This is the ' . $page_title . ' page. Edit this content via Dashboard > Pages.</p>',
                'post_status' => 'publish',
                'post_author' => 1
            );
            wp_insert_post($page_data);
        }
    }

    // Set 'Home' as the static front page and 'Blog' as the posts page.
    $home_page = get_page_by_path('home');
    $blog_page = get_page_by_path('blog');

    if ($home_page) {
        update_option('page_on_front', $home_page->ID);
        update_option('show_on_front', 'page');
    }
    if ($blog_page) {
        update_option('page_for_posts', $blog_page->ID);
    }
}
add_action('after_switch_theme', 'presspilot_create_required_pages');
