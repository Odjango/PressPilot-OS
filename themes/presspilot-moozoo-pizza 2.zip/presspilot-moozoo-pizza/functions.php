<?php
/**
 * Theme functions and definitions
 */

if ( ! function_exists( 'presspilot_moozoo_pizza_support' ) ) :
	function presspilot_moozoo_pizza_support() {
		add_theme_support( 'wp-block-styles' );
		add_theme_support( 'editor-styles' );
		add_theme_support( 'block-templates' );
        add_theme_support( 'menus' );
        add_theme_support( 'post-thumbnails' );
        add_theme_support( 'automatic-feed-links' );
        add_theme_support( 'title-tag' );
	}
endif;
add_action( 'after_setup_theme', 'presspilot_moozoo_pizza_support' );

/**
 * Register block patterns
 */
function presspilot_moozoo_pizza_register_patterns() {
    register_block_pattern_category(
        'featured',
        array( 'label' => __( 'Featured', 'presspilot-moozoo-pizza' ) )
    );
}
add_action( 'init', 'presspilot_moozoo_pizza_register_patterns' );

/**
 * Content Setup - Nuke & Pave
 */
function presspilot_moozoo_pizza_content_setup() {
    // 1. Nuke existing content
    $all_pages = get_posts(array('post_type' => 'page', 'numberposts' => -1, 'post_status' => 'any'));
    foreach ($all_pages as $p) {
        wp_delete_post($p->ID, true);
    }

    $nav_menus = get_terms(array('taxonomy' => 'nav_menu', 'hide_empty' => false));
    if (!is_wp_error($nav_menus)) {
        foreach ($nav_menus as $menu) {
            wp_delete_nav_menu($menu->term_id);
        }
    }

    $nav_posts = get_posts(array('post_type' => 'wp_navigation', 'numberposts' => -1, 'post_status' => 'any'));
    foreach ($nav_posts as $p) {
        wp_delete_post($p->ID, true);
    }

    // 2. Update Site Title
    update_option('blogname', 'MooZoo Pizza');
    update_option('blogdescription', 'The Best Pizza in Town');

    // 3. Create Pages with Rich Content (3 Sections)
    $user_id = get_current_user_id();
    if (!$user_id) {
        $users = get_users(array('role' => 'administrator'));
        $user_id = !empty($users) ? $users[0]->ID : 1;
    }

    $pages_data = array(
        'Home' => 'Welcome to MooZoo Pizza.', // Home uses front-page.html, so content matters less, but good to have.
        'Menu' => 'Explore our mouth-watering menu.',
        'About' => 'Our story began in a small barn...',
        'Services' => 'We deliver happiness to your door.',
        'Blog' => 'Pizza news and cheesy updates.',
        'Contact' => 'Visit us at the farm.'
    );

    $page_ids = array();
    foreach ($pages_data as $title => $desc) {
        
        // Construct 3-Section Content
        // Section 1: Hero
        $hero_html = '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"},"blockGap":"var:preset|spacing|30"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)">
    <!-- wp:heading {"level":1,"style":{"typography":{"fontSize":"var:preset|font-size|xx-large"}}} -->
    <h1 style="font-size:var(--wp--preset--font-size--xx-large)">' . $title . '</h1>
    <!-- /wp:heading -->
    <!-- wp:paragraph {"style":{"typography":{"fontSize":"var:preset|font-size|medium"}}} -->
    <p style="font-size:var(--wp--preset--font-size--medium)">' . $desc . '</p>
    <!-- /wp:paragraph -->
</div>
<!-- /wp:group -->';

        // Section 2: Main Content
        $content_html = '<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">
    <!-- wp:heading -->
    <h2>Details</h2>
    <!-- /wp:heading -->
    <!-- wp:paragraph -->
    <p>Here at MooZoo, we take pride in our ingredients. Every slice is a masterpiece of flavor and texture. This section contains the main details for the ' . $title . ' page.</p>
    <!-- /wp:paragraph -->
    <!-- wp:paragraph -->
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
    <!-- /wp:paragraph -->
</div>
<!-- /wp:group -->';

        // Section 3: Features (Reusing Home Services Pattern for consistency)
        $features_html = '<!-- wp:pattern {"slug":"presspilot/home-services"} /-->';

        $full_content = $hero_html . $content_html . $features_html;

        $page_id = wp_insert_post(array(
            'post_title'    => $title,
            'post_content'  => $full_content,
            'post_status'   => 'publish',
            'post_type'     => 'page',
            'post_author'   => $user_id
        ));
        if (!is_wp_error($page_id)) {
            $page_ids[$title] = $page_id;
        }
    }

    // 4. Set Front Page & Posts Page
    if (isset($page_ids['Home']) && isset($page_ids['Blog'])) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $page_ids['Home']);
        update_option('page_for_posts', $page_ids['Blog']);
    }

    // 5. Create Navigation Menu
    $menu_items_html = '';
    foreach ($page_ids as $title => $id) {
        $permalink = get_permalink($id);
        $menu_items_html .= '<!-- wp:navigation-link {"label":"' . $title . '","type":"page","id":' . $id . ',"url":"' . $permalink . '","kind":"post-type"} /-->';
    }

    // Create the Navigation Post
    $nav_post_id = wp_insert_post(array(
        'post_title'    => 'Primary Navigation',
        'post_content'  => '<!-- wp:navigation {"ref":' . $nav_post_id . '} -->' . $menu_items_html . '<!-- /wp:navigation -->',
        'post_status'   => 'publish',
        'post_type'     => 'wp_navigation',
        'post_name'     => 'primary-navigation',
        'post_author'   => $user_id
    ));
    
    if (!is_wp_error($nav_post_id)) {
         wp_update_post(array(
            'ID' => $nav_post_id,
            'post_content' => $menu_items_html
        ));
    }
}

add_action('after_switch_theme', 'presspilot_moozoo_pizza_content_setup');

function presspilot_moozoo_pizza_version_check() {
    $ver = '1.0.1';
    $opt = get_option('presspilot_moozoo_pizza_version');
    if ($opt !== $ver) {
        presspilot_moozoo_pizza_content_setup();
        update_option('presspilot_moozoo_pizza_version', $ver);
    }
}
add_action('admin_init', 'presspilot_moozoo_pizza_version_check');
