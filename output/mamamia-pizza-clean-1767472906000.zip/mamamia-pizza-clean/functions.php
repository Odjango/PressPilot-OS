<?php
/**
 * PressPilot Base Theme Functions
 *
 * @package PressPilot
 * @author  WP Modern Architect
 * @since   1.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * 1. Global Theme Setup
 * Handles basic FSE support and asset loading.
 */
function presspilot_theme_setup()
{
    // Add support for block styles.
    add_theme_support('wp-block-styles');

    // Enqueue editor styles.
    add_theme_support('editor-styles');
    add_editor_style('assets/css/editor-style.css'); // Optional: for strict editor overrides

    // Add support for full and wide align images.
    add_theme_support('align-wide');

    // Add support for responsive embeds.
    add_theme_support('responsive-embeds');

    // Add support for custom line heights.
    add_theme_support('custom-line-height');

    // Add support for post thumbnails (images).
    add_theme_support('post-thumbnails');
}
add_action('after_setup_theme', 'presspilot_theme_setup');


/**
 * 2. Enqueue Scripts & Styles
 * Note: specific block styles are loaded via block.json, not here!
 */
function presspilot_enqueue_assets()
{
    // Enqueue the main stylesheet (metadata + fallback).
    wp_enqueue_style(
        'presspilot-style',
        get_stylesheet_uri(),
        array(),
        wp_get_theme()->get('Version')
    );
}
add_action('wp_enqueue_scripts', 'presspilot_enqueue_assets');


/**
 * 3. The "Drop-in" ACF Block Auto-Loader ⚡️
 * Automatically registers any block found in the /blocks/ directory.
 */
function presspilot_register_acf_blocks()
{

    // 1. Check if blocks directory exists
    $blocks_directory = get_theme_file_path('/blocks/');
    if (!file_exists($blocks_directory)) {
        return;
    }

    // 2. Find all block.json files inside subdirectories
    $block_json_files = glob($blocks_directory . '*/block.json');

    // 3. Register each block found
    if ($block_json_files) {
        foreach ($block_json_files as $filename) {
            register_block_type($filename);
        }
    }
}
add_action('init', 'presspilot_register_acf_blocks');


/**
 * 4. ACF Local JSON Sync (Crucial for Version Control)
 * Saves your Field Group configurations to the /acf-json/ folder.
 */
function presspilot_acf_json_save_point($path)
{
    $path = get_stylesheet_directory() . '/acf-json';
    return $path;
}
add_filter('acf/settings/save_json', 'presspilot_acf_json_save_point');

function presspilot_acf_json_load_point($paths)
{
    unset($paths[0]);
    $paths[] = get_stylesheet_directory() . '/acf-json';
    return $paths;
}
add_filter('acf/settings/load_json', 'presspilot_acf_json_load_point');

// Include Activator for Site Identity/Seeding if present (keeping this from previous logic as it's useful!)
if (file_exists(get_stylesheet_directory() . '/inc/activator.php')) {
    require_once get_stylesheet_directory() . '/inc/activator.php';
}
