<?php
/**
 * Title: PressPilot – Pricing Columns
 * Slug: presspilot/pricing-columns
 * Categories: presspilot, presspilot-starter
 * Description: Three-column pricing grid for PressPilot Golden Foundation.
 */
?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|50","right":"var:preset|spacing|40","bottom":"var:preset|spacing|50","left":"var:preset|spacing|40"}}},"layout":{"type":"constrained","contentSize":"1100px"}} -->
<div class="wp-block-group is-layout-constrained"
  style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--40)">
  <!-- wp:heading {"textAlign":"center","level":2,"fontSize":"xl"} -->
  <h2 class="wp-block-heading has-text-align-center has-xl-font-size">Plans for every service</h2>
  <!-- /wp:heading -->

  <!-- wp:paragraph {"align":"center","textColor":"muted","fontSize":"sm"} -->
  <p class="has-text-align-center has-muted-color has-sm-font-size">PressPilot Demo Co. can switch tiers any time—kits stay in sync automatically.</p>
  <!-- /wp:paragraph -->

  <!-- wp:columns {"style":{"spacing":{"margin":{"top":"var:preset|spacing|40"},"blockGap":"var:preset|spacing|40"}}} -->
  <div class="wp-block-columns" style="margin-top:var(--wp--preset--spacing--40);gap:var(--wp--preset--spacing--40)">
    <!-- wp:column -->
    <div class="wp-block-column">
      <!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|30"},"border":{"width":"1px","style":"solid","color":"var:preset|color|border","radius":"28px"},"padding":{"top":"var:preset|spacing|40","right":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40"},"shadow":"var:preset|shadow|card"},"layout":{"type":"constrained"},"className":""} -->
      <div class="wp-block-group "
        style="border-color:var(--wp--preset--color--border);border-style:solid;border-width:1px;border-radius:28px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40);box-shadow:var(--wp--preset--shadow--card)">
        <!-- wp:heading {"level":3,"fontSize":"lg"} -->
        <h3 class="wp-block-heading has-lg-font-size">Starter</h3>
        <!-- /wp:heading -->
        <!-- wp:paragraph {"fontSize":"xl"} -->
        <p class="has-xl-font-size">$19 / month</p>
        <!-- /wp:paragraph -->
        <!-- wp:list {"fontSize":"sm"} -->
        <ul class="has-sm-font-size"><li class="pp-plan-feature">1 brand setup</li><li class="pp-plan-feature">Basic analytics</li><li class="pp-plan-feature">Email support</li></ul>
        <!-- /wp:list -->
        <!-- wp:buttons {"layout":{"type":"flex","justifyContent":"stretch"}} -->
        <div class="wp-block-buttons is-layout-flex is-content-justification-stretch">
          <!-- wp:button {"width":100,"backgroundColor":"primary","textColor":"soft-bg","style":{"shadow":"var:preset|shadow|primary-glow"}} -->
          <div class="wp-block-button has-custom-width wp-block-button__width-100"><a
              class="wp-block-button__link has-soft-bg-color has-primary-background-color has-text-color has-background wp-element-button"
              style="box-shadow:var(--wp--preset--shadow--primary-glow)" href="#contact">Choose Starter</a></div>
          <!-- /wp:button -->
        </div>
        <!-- /wp:buttons -->
      </div>
      <!-- /wp:group -->
    </div>
    <!-- /wp:column -->

    <!-- wp:column -->
    <div class="wp-block-column">
      <!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|30"},"border":{"width":"2px","style":"solid","color":"var:preset|color|primary","radius":"28px"},"padding":{"top":"var:preset|spacing|40","right":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40"},"shadow":"var:preset|shadow|primary-glow"},"layout":{"type":"constrained"},"className":" highlight"} -->
      <div class="wp-block-group  highlight"
        style="border-color:var(--wp--preset--color--primary);border-style:solid;border-width:2px;border-radius:28px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40);box-shadow:var(--wp--preset--shadow--primary-glow)">
        <!-- wp:heading {"level":3,"fontSize":"lg"} -->
        <h3 class="wp-block-heading has-lg-font-size">Growth</h3>
        <!-- /wp:heading -->
        <!-- wp:paragraph {"fontSize":"xl"} -->
        <p class="has-xl-font-size">$49 / month</p>
        <!-- /wp:paragraph -->
        <!-- wp:list {"fontSize":"sm"} -->
        <ul class="has-sm-font-size"><li class="pp-plan-feature">Unlimited kits</li><li class="pp-plan-feature">Mode-aware add-ons</li><li class="pp-plan-feature">Priority support</li></ul>
        <!-- /wp:list -->
        <!-- wp:buttons {"layout":{"type":"flex","justifyContent":"stretch"}} -->
        <div class="wp-block-buttons is-layout-flex is-content-justification-stretch">
          <!-- wp:button {"width":100,"backgroundColor":"primary","textColor":"soft-bg","style":{"shadow":"var:preset|shadow|primary-glow"}} -->
          <div class="wp-block-button has-custom-width wp-block-button__width-100"><a
              class="wp-block-button__link has-soft-bg-color has-primary-background-color has-text-color has-background wp-element-button"
              style="box-shadow:var(--wp--preset--shadow--primary-glow)" href="#contact">Choose Growth</a></div>
          <!-- /wp:button -->
        </div>
        <!-- /wp:buttons -->
      </div>
      <!-- /wp:group -->
    </div>
    <!-- /wp:column -->

    <!-- wp:column -->
    <div class="wp-block-column">
      <!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|30"},"border":{"width":"1px","style":"solid","color":"var:preset|color|border","radius":"28px"},"padding":{"top":"var:preset|spacing|40","right":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40"},"shadow":"var:preset|shadow|card"},"layout":{"type":"constrained"},"className":""} -->
      <div class="wp-block-group "
        style="border-color:var(--wp--preset--color--border);border-style:solid;border-width:1px;border-radius:28px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40);box-shadow:var(--wp--preset--shadow--card)">
        <!-- wp:heading {"level":3,"fontSize":"lg"} -->
        <h3 class="wp-block-heading has-lg-font-size">Pro</h3>
        <!-- /wp:heading -->
        <!-- wp:paragraph {"fontSize":"xl"} -->
        <p class="has-xl-font-size">$99 / month</p>
        <!-- /wp:paragraph -->
        <!-- wp:list {"fontSize":"sm"} -->
        <ul class="has-sm-font-size"><li class="pp-plan-feature">Dedicated strategist</li><li class="pp-plan-feature">Custom exports</li><li class="pp-plan-feature">Training & SLA</li></ul>
        <!-- /wp:list -->
        <!-- wp:buttons {"layout":{"type":"flex","justifyContent":"stretch"}} -->
        <div class="wp-block-buttons is-layout-flex is-content-justification-stretch">
          <!-- wp:button {"width":100,"backgroundColor":"primary","textColor":"soft-bg","style":{"shadow":"var:preset|shadow|primary-glow"}} -->
          <div class="wp-block-button has-custom-width wp-block-button__width-100"><a
              class="wp-block-button__link has-soft-bg-color has-primary-background-color has-text-color has-background wp-element-button"
              style="box-shadow:var(--wp--preset--shadow--primary-glow)" href="#contact">Choose Pro</a></div>
          <!-- /wp:button -->
        </div>
        <!-- /wp:buttons -->
      </div>
      <!-- /wp:group -->
    </div>
    <!-- /wp:column -->
  </div>
  <!-- /wp:columns -->
</div>
<!-- /wp:group -->