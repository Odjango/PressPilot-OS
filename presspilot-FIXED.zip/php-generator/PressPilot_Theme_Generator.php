<?php

/**
 * Class PressPilot_Theme_Generator
 *
 * Handles the server-side generation of a Twenty Twenty-Four child theme
 * based on user input, using OpenAI for content generation.
 */
class PressPilot_Theme_Generator
{

    private $base_temp_dir;
    private $uploads_url;
    private $api_key;

    public function __construct()
    {
        if (function_exists('wp_upload_dir')) {
            $upload_dir = wp_upload_dir();
            $this->base_temp_dir = $upload_dir['basedir'] . '/presspilot-temp/';
            $this->uploads_url = $upload_dir['baseurl'] . '/presspilot-generated/';
        } else {
            $this->base_temp_dir = sys_get_temp_dir() . '/presspilot-temp/';
            $this->uploads_url = '/uploads/presspilot-generated/';
        }

        if (defined('PRESSPILOT_OPENAI_KEY')) {
            $this->api_key = PRESSPILOT_OPENAI_KEY;
        }
    }

    public function generate($request_data)
    {
        // Validation
        if (empty($request_data['business_name'])) {
            return ['error' => 'Business Name is required.'];
        }

        $unique_id = uniqid();
        $theme_slug = 'presspilot-' . $unique_id;
        $industry = $request_data['business_type'];

        // 1. Prepare Data ("The Mixer")
        $patterns = $this->get_patterns_for_industry($industry);
        $colors = $this->get_branding_colors($industry, $request_data['business_description']);
        $nav_links = $this->get_navigation_links($industry);

        $theme_data = [
            'business_name' => $request_data['business_name'],
            'business_tagline' => $request_data['business_tagline'] ?? '',
            'description' => $request_data['business_description'],
            'language' => $request_data['content_language'] ?? 'English',
            'industry' => $industry,
            'colors' => $colors,
            'fonts' => ['heading' => 'Inter', 'body' => 'Inter'],
            'patterns' => $patterns,
            'navigation' => $nav_links
        ];

        // 2. Call OpenAI API ("The Gas Line")
        $system_prompt = "You are a professional web copywriter. You must output valid JSON only.";
        $user_prompt = $this->construct_content_prompt($theme_data);

        $ai_content = $this->call_openai_api($system_prompt, $user_prompt, $patterns);

        // 3. Setup Directory
        $theme_dir = $this->setup_directory($unique_id, $theme_slug);
        if (!$theme_dir) {
            return ['error' => 'Failed to create directory.'];
        }

        // 4. Create Essential Files
        $this->create_style_css($theme_dir, $theme_slug);
        $this->create_theme_json($theme_dir, $theme_data);

        // 5. Assemble Templates (Home & Header)
        $this->assemble_homepage($theme_dir, $theme_data, $ai_content);

        // 6. Generate Special Pages (Menu, Shop, etc.)
        $this->generate_special_pages($theme_dir, $theme_data, $ai_content);

        // 7. Package
        $zip_url = $this->package_theme($theme_dir, $unique_id, $theme_slug);

        return [
            'success' => true,
            'download_url' => $zip_url,
            'unique_id' => $unique_id
        ];
    }

    // --- LOGIC: SMART NAVIGATION ---

    private function get_navigation_links($industry)
    {
        // Base Links
        $links = [
            ['label' => 'Home', 'url' => '/'],
            ['label' => 'About', 'url' => '/about']
        ];

        // Industry Extensions
        if (stripos($industry, 'Restaurant') !== false || stripos($industry, 'Food') !== false) {
            $links[] = ['label' => 'Menu', 'url' => '/menu'];
            $links[] = ['label' => 'Reservations', 'url' => '/reservations'];
        } elseif (stripos($industry, 'Fitness') !== false || stripos($industry, 'Gym') !== false) {
            $links[] = ['label' => 'Classes', 'url' => '/classes'];
            $links[] = ['label' => 'Trainers', 'url' => '/trainers'];
        } elseif (stripos($industry, 'Store') !== false || stripos($industry, 'E-commerce') !== false) {
            $links[] = ['label' => 'Shop', 'url' => '/shop'];
            $links[] = ['label' => 'Cart', 'url' => '/cart'];
            $links[] = ['label' => 'My Account', 'url' => '/my-account'];
        } else {
            // Corporate / Default
            $links[] = ['label' => 'Services', 'url' => '/services'];
        }

        $links[] = ['label' => 'Contact', 'url' => '/contact'];

        return $links;
    }

    // --- LOGIC: AI PROMPTING ---

    private function construct_content_prompt($data)
    {
        $patterns_list = implode(', ', $data['patterns']);

        $prompt = "Create website content for a {$data['business_name']} ({$data['business_tagline']}). ";
        $prompt .= "Description: {$data['description']}. ";
        $prompt .= "Industry: {$data['industry']}. ";
        $prompt .= "Language: {$data['language']}. ";
        $prompt .= "Generate a JSON object with keys: $patterns_list";

        // Special Data Requests
        if (stripos($data['industry'], 'Restaurant') !== false) {
            $prompt .= ", 'menu_items'. For 'menu_items', return an array of 5 objects with 'name', 'price', 'description'. ";
        }
        if (stripos($data['industry'], 'E-commerce') !== false) {
            $prompt .= ", 'featured_products'. For 'featured_products', return an array of 3 objects with 'name', 'price', 'description'. ";
        }

        $prompt .= ". All pattern keys should have 'headline', 'subheadline', 'cta_text' fields.";

        return $prompt;
    }

    private function call_openai_api($system_prompt, $user_prompt, $patterns)
    {
        if (!$this->api_key || !function_exists('wp_remote_post')) {
            return $this->get_fallback_content($patterns);
        }

        $body = [
            'model' => 'gpt-4o-mini',
            'messages' => [
                ['role' => 'system', 'content' => $system_prompt],
                ['role' => 'user', 'content' => $user_prompt]
            ],
            'response_format' => ['type' => 'json_object'],
            'temperature' => 0.7
        ];

        $args = [
            'body' => json_encode($body),
            'headers' => [
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json',
            ],
            'timeout' => 45, // Increased timeout for larger content
        ];

        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', $args);

        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            return $this->get_fallback_content($patterns);
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (!empty($data['choices'][0]['message']['content'])) {
            $content_json = json_decode($data['choices'][0]['message']['content'], true);
            if (json_last_error() === JSON_ERROR_NONE) {
                return $content_json;
            }
        }
        return $this->get_fallback_content($patterns);
    }

    private function get_fallback_content($patterns)
    {
        $content = ['is_fallback' => true];
        foreach ($patterns as $pattern) {
            $content[$pattern] = [
                'headline' => ucfirst(str_replace('-', ' ', $pattern)) . ' Headline',
                'subheadline' => 'Placeholder description.',
                'cta_text' => 'Learn More'
            ];
        }
        // Fallback for special arrays
        $content['menu_items'] = [
            ['name' => 'Sample Dish', 'price' => '$10', 'description' => 'Tasty dish.'],
            ['name' => 'Sample Drink', 'price' => '$5', 'description' => 'Refreshing drink.']
        ];
        $content['featured_products'] = [
            ['name' => 'Sample Product', 'price' => '$20', 'description' => 'Great product.']
        ];
        return $content;
    }

    // --- LOGIC: TEMPLATE ASSEMBLY ---

    private function assemble_homepage($theme_dir, $theme_data, $ai_content)
    {
        $page_blocks = [];

        // 1. DYNAMIC HEADER
        // We build the header manually as a Group block structure instead of a static template part
        // so we can inject the custom navigation links.
        $nav_inner_blocks = [];
        foreach ($theme_data['navigation'] as $link) {
            $nav_inner_blocks[] = [
                'blockName' => 'core/navigation-link',
                'attrs' => ['label' => $link['label'], 'url' => $link['url'], 'kind' => 'custom'],
                // Navigation links are self-closing basically
                'innerContent' => []
            ];
        }

        $header_structure = [
            'blockName' => 'core/group',
            'attrs' => ['tagName' => 'header', 'layout' => ['type' => 'flex', 'justifyContent' => 'space-between']],
            'innerBlocks' => [
                [
                    'blockName' => 'core/site-title',
                    'attrs' => ['level' => 1]
                ],
                [
                    'blockName' => 'core/navigation',
                    'attrs' => ['layout' => ['type' => 'flex', 'justifyContent' => 'right']],
                    'innerBlocks' => $nav_inner_blocks
                ]
            ]
        ];
        $page_blocks[] = $header_structure;

        // 2. PATTERNS LOOP
        foreach ($theme_data['patterns'] as $pattern_slug) {
            $p_content = $ai_content[$pattern_slug] ?? [];
            $headline = $p_content['headline'] ?? 'Section Title';
            $subhead = $p_content['subheadline'] ?? '';

            $page_blocks[] = [
                'blockName' => 'core/group',
                'attrs' => ['tagName' => 'section', 'layout' => ['type' => 'constrained'], 'className' => "pattern-$pattern_slug"],
                'innerBlocks' => [
                    ['blockName' => 'core/heading', 'attrs' => ['level' => 2], 'innerHTML' => $headline, 'innerContent' => [$headline]],
                    ['blockName' => 'core/paragraph', 'innerHTML' => $subhead, 'innerContent' => [$subhead]]
                ],
                'innerContent' => ['<section class="wp-block-group">', null, null, '</section>']
            ];
        }

        // 3. FOOTER (Static Part)
        $page_blocks[] = [
            'blockName' => 'core/template-part',
            'attrs' => ['slug' => 'footer', 'theme' => 'twentytwentyfour', 'tagName' => 'footer']
        ];

        $html = '';
        foreach ($page_blocks as $block) {
            $html .= (function_exists('serialize_block')) ? serialize_block($block) : '<!-- Block -->';
        }

        file_put_contents($theme_dir . '/templates/home.html', $html);
    }

    private function generate_special_pages($theme_dir, $theme_data, $ai_content)
    {

        // RESTAURANT: Menu Page
        if (stripos($theme_data['industry'], 'Restaurant') !== false) {
            $menu_items = $ai_content['menu_items'] ?? [];
            $blocks = [];

            // Header
            $blocks[] = ['blockName' => 'core/heading', 'attrs' => ['level' => 1], 'innerHTML' => 'Our Menu', 'innerContent' => ['Our Menu']];

            // Menu Items Grid
            foreach ($menu_items as $item) {
                $blocks[] = [
                    'blockName' => 'core/group',
                    'attrs' => ['style' => ['border' => ['width' => '1px']]],
                    'innerBlocks' => [
                        ['blockName' => 'core/heading', 'attrs' => ['level' => 3], 'innerHTML' => $item['name'] . ' - ' . $item['price']],
                        ['blockName' => 'core/paragraph', 'innerHTML' => $item['description']]
                    ],
                    'innerContent' => ['<div class="menu-item">', null, null, '</div>']
                ];
            }

            $html = '';
            foreach ($blocks as $b) {
                $html .= (function_exists('serialize_block')) ? serialize_block($b) : '';
            }
            file_put_contents($theme_dir . '/templates/page-menu.html', $html);
        }

        // E-COMMERCE: Product Archive (Stub)
        if (stripos($theme_data['industry'], 'E-commerce') !== false) {
            // Just a placeholder for WooCommerce loop
            $html = '<!-- wp:group {"layout":{"type":"constrained"}} --><div class="wp-block-group"><!-- wp:heading --><h1>Shop</h1><!-- /wp:heading --><!-- wp:woocommerce/product-query /--></div><!-- /wp:group -->';
            file_put_contents($theme_dir . '/templates/archive-product.html', $html);
        }
    }

    // --- UTILITIES ---

    private function get_patterns_for_industry($industry)
    {
        // ... (Same as Phase 2) ...
        switch ($industry) {
            case 'Restaurant / Food Service':
                return ['hero', 'menu-grid', 'reservation-cta', 'testimonials'];
            case 'Fitness / Gym / Wellness':
                return ['hero', 'class-schedule', 'trainer-grid', 'membership-pricing'];
            case 'Corporate / Professional Services':
                return ['hero', 'services-3-col', 'about-team', 'contact-form'];
            case 'E-commerce / Online Store':
                return ['hero', 'featured-products', 'shop-benefits', 'newsletter'];
            default:
                return ['hero', 'text-split', 'cta'];
        }
    }

    private function get_branding_colors($industry, $desc)
    {
        // ... (Same as Phase 2) ...
        if (stripos($industry, 'Food') !== false) {
            return ['primary' => '#ef4444', 'secondary' => '#78350f', 'accent' => '#f59e0b', 'base' => '#ffffff', 'contrast' => '#000000'];
        }
        if (stripos($industry, 'Fitness') !== false) {
            return ['primary' => '#84cc16', 'secondary' => '#171717', 'accent' => '#ecfccb', 'base' => '#ffffff', 'contrast' => '#000000'];
        }
        if (stripos($industry, 'Corporate') !== false) {
            return ['primary' => '#0f172a', 'secondary' => '#64748b', 'accent' => '#3b82f6', 'base' => '#f8fafc', 'contrast' => '#0f172a'];
        }
        return ['primary' => '#000000', 'secondary' => '#ffffff', 'accent' => '#666666', 'base' => '#ffffff', 'contrast' => '#000000'];
    }

    private function setup_directory($unique_id, $theme_slug)
    {
        $path = $this->base_temp_dir . $unique_id . '/' . $theme_slug;
        if (!is_dir($path)) {
            mkdir($path, 0755, true);
        }
        if (!is_dir($path . '/templates')) {
            mkdir($path . '/templates', 0755, true);
        }
        return $path;
    }

    private function create_style_css($dir, $slug)
    {
        $header = "/*\nTheme Name: PressPilot Generated Theme\nTemplate: twentytwentyfour\n*/";
        file_put_contents($dir . '/style.css', $header);
    }

    private function create_theme_json($dir, $data)
    {
        $json = ['version' => 2, 'settings' => ['color' => ['palette' => []], 'typography' => ['fontFamilies' => []]]];
        foreach ($data['colors'] as $k => $v) {
            $json['settings']['color']['palette'][] = ['slug' => $k, 'color' => $v, 'name' => ucfirst($k)];
        }
        file_put_contents($dir . '/theme.json', json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    }

    private function package_theme($dir, $id, $slug)
    {
        $zip_filename = $slug . '.zip';
        $public_dir = wp_upload_dir()['basedir'] . '/presspilot-generated/';
        if (!is_dir($public_dir))
            mkdir($public_dir, 0755, true);

        $zip = new ZipArchive();
        if ($zip->open($public_dir . $zip_filename, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
            $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir), RecursiveIteratorIterator::LEAVES_ONLY);
            foreach ($files as $file) {
                if (!$file->isDir()) {
                    $zip->addFile($file->getRealPath(), substr($file->getRealPath(), strlen($this->base_temp_dir . $id . '/')));
                }
            }
            $zip->close();
        }
        return $this->uploads_url . $zip_filename;
    }
}
