<?php
/**
 * Title: PressPilot – Contact Simple
 * Slug: presspilot/contact-simple
 * Categories: presspilot, presspilot-starter
 * Description: Simple contact split layout for PressPilot Golden Foundation.
 */
?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}}},"layout":{"type":"constrained","contentSize":"960px"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--40)">
  <!-- wp:columns {"style":{"spacing":{"blockGap":"var:preset|spacing|40"}}} -->
  <div class="wp-block-columns">
    <!-- wp:column -->
    <div class="wp-block-column">
      <!-- wp:heading {"level":2,"fontSize":"xl"} -->
      <h2 class="wp-block-heading has-xl-font-size pp-contact-heading">Ready to work with Tonny Pizza?</h2>
      <!-- /wp:heading -->
      <!-- wp:paragraph {"fontSize":"sm"} -->
      <p class="has-sm-font-size pp-contact-body">Share a bit about your services and the neighborhoods you cover. We’ll tailor the kit around it. Reach us at hello@tonny-pizza.com.</p>
      <!-- /wp:paragraph -->
      <!-- wp:list {"fontSize":"sm"} -->
      <ul class="has-sm-font-size pp-contact-body"><li><strong>Email:</strong> <span class="pp-contact-email">hello@tonny-pizza.com</span></li></ul>
      <!-- /wp:list -->
    </div>
    <!-- /wp:column -->

    <!-- wp:column -->
    <div class="wp-block-column">
      <!-- wp:group {"style":{"border":{"width":"1px","style":"solid","color":"var:preset|color|border"},"spacing":{"padding":{"top":"var:preset|spacing|40","right":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40"}}},"layout":{"type":"constrained"}} -->
      <div class="wp-block-group" style="border-color:var(--wp--preset--color--border);border-style:solid;border-width:1px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)">
        <!-- wp:paragraph {"fontSize":"sm"} -->
        <p class="has-sm-font-size pp-contact-body">Request a callback</p>
        <!-- /wp:paragraph -->
      </div>
      <!-- /wp:group -->
    </div>
    <!-- /wp:column -->
  </div>
  <!-- /wp:columns -->
</div>
<!-- /wp:group -->
